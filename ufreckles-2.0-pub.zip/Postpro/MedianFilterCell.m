function EE=MedianFilterCell(conn,E)
EE=zeros(size(E));
if size(conn,2)>3
    assert(~any(conn(:,4)>0));
end
conn=conn(:,1:3);
elt=3*ones(size(conn,1),1);
comp=size(E,1)/numel(elt);
for ie=1:numel(elt)
   inods=conn(ie,:);
   ielts=GetEltsFromNodes(conn,elt,inods);
   for icomp=0:(comp-1)
       for in=1:size(E,2)
           EE(ie+icomp*numel(elt),in)=median(E(ielts+icomp*numel(elt),in));
       end
   end
    
end



end