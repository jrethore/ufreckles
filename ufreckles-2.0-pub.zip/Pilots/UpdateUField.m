function [Ut]=UpdateUField(nmod,P)
Ut=0;
error('you must say how the displacement field is updated');

end