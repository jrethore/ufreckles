function [dummy]=UpdateMaterial(nmod,P,U)
dummy=0;

error('you must say how the material model is updated');

end